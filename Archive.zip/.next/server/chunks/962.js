exports.id = 962;
exports.ids = [962];
exports.modules = {

/***/ 4457:
/***/ ((module) => {

// Exports
module.exports = {
	"spinner": "styles_spinner__OeeP6"
};


/***/ }),

/***/ 3891:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Spinner)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_module_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4457);
/* harmony import */ var _styles_module_scss__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styles_module_scss__WEBPACK_IMPORTED_MODULE_1__);


function Spinner() {
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
        className: (_styles_module_scss__WEBPACK_IMPORTED_MODULE_1___default().spinner),
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("circle", {
            cx: "30",
            cy: "30",
            r: "28"
        })
    }));
};


/***/ }),

/***/ 5313:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Hj": () => (/* binding */ useGithubOrgMembers),
/* harmony export */   "QY": () => (/* binding */ useAdminData),
/* harmony export */   "cC": () => (/* binding */ saveGithubCredentials),
/* harmony export */   "Dj": () => (/* binding */ importNewData),
/* harmony export */   "EW": () => (/* binding */ useGithubTeams),
/* harmony export */   "YH": () => (/* binding */ useGithubTeamRepos),
/* harmony export */   "XX": () => (/* binding */ useGithubTeamMembers),
/* harmony export */   "SL": () => (/* binding */ useGithubOrgActivities),
/* harmony export */   "DY": () => (/* binding */ createNewTeam),
/* harmony export */   "fC": () => (/* binding */ deleteTeam),
/* harmony export */   "Dd": () => (/* binding */ inviteMemberToTeam),
/* harmony export */   "F0": () => (/* binding */ removeMemberFromTeam)
/* harmony export */ });
/* unused harmony export getAccessToken */
/* harmony import */ var swr__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(549);
/* harmony import */ var swr__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(swr__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);


async function getAccessToken() {
    const { accessToken  } = await axios__WEBPACK_IMPORTED_MODULE_1___default().get("/api/get-access-token").then((res)=>res.data
    ).catch((err)=>{
        console.log(err);
        throw new Error(err);
    });
    return accessToken;
}
// list all members within a github organization
function useGithubOrgMembers(url = "") {
    const fetchMembers = async (_url)=>{
        const accessToken = await getAccessToken();
        return await axios__WEBPACK_IMPORTED_MODULE_1___default().get(_url, {
            headers: {
                Authorization: `Bearer ${accessToken}`
            }
        }).then((res)=>res.data.members
        );
    };
    const { data , error  } = swr__WEBPACK_IMPORTED_MODULE_0___default()(url, fetchMembers);
    return {
        members: data,
        membersLoadingError: error
    };
}
function useAdminData(url = "") {
    const fetcher = async (_url)=>{
        const accessToken = await getAccessToken();
        return await axios__WEBPACK_IMPORTED_MODULE_1___default().get(`${_url}`, {
            headers: {
                Authorization: `Bearer ${accessToken}`
            }
        }).then((res)=>res.data.admin
        );
    };
    const { data , error  } = swr__WEBPACK_IMPORTED_MODULE_0___default()(url, fetcher);
    return {
        admin: data,
        loadAdminError: error
    };
}
async function saveGithubCredentials(url = "", apiKey = "", organization = "") {
    const accessToken = await getAccessToken();
    const result = await axios__WEBPACK_IMPORTED_MODULE_1___default().post(url, {
        apiKey,
        organization
    }, {
        headers: {
            Authorization: `Bearer ${accessToken}`
        }
    }).then((res)=>res.data
    );
    if (!(result === null || result === void 0 ? void 0 : result.ok)) throw new Error(result === null || result === void 0 ? void 0 : result.message);
    return result;
}
async function importNewData(url = "") {
    const accessToken = await getAccessToken();
    const result = await axios__WEBPACK_IMPORTED_MODULE_1___default().put(url, {}, {
        headers: {
            Authorization: `Bearer ${accessToken}`
        }
    }).then((res)=>res.data
    );
    if (!(result === null || result === void 0 ? void 0 : result.ok)) throw new Error(result === null || result === void 0 ? void 0 : result.message);
    return result;
}
function useGithubTeams(url = "") {
    const fetchTeams = async (_url)=>{
        const accessToken = await getAccessToken();
        return await axios__WEBPACK_IMPORTED_MODULE_1___default().get(_url, {
            headers: {
                Authorization: `Bearer ${accessToken}`
            }
        }).then((res)=>res.data.teams
        );
    };
    const { data , error  } = swr__WEBPACK_IMPORTED_MODULE_0___default()(url, fetchTeams);
    return {
        teams: data,
        teamsLoadError: error
    };
}
// fetch all the repositories of a team from github
function useGithubTeamRepos(url1 = "") {
    const fetcher = async (url)=>{
        const accessToken = await getAccessToken();
        return await axios__WEBPACK_IMPORTED_MODULE_1___default().get(`${url}`, {
            headers: {
                Authorization: `Bearer ${accessToken}`
            }
        }).then((res)=>{
            if (!res.data.ok) throw new Error(res.data.message);
            return res.data.repos;
        });
    };
    const { data , error  } = swr__WEBPACK_IMPORTED_MODULE_0___default()(url1, fetcher);
    return {
        repos: data,
        loadReposError: error
    };
}
function useGithubTeamMembers(url2 = "") {
    const fetcher = async (url)=>{
        const accessToken = await getAccessToken();
        return await axios__WEBPACK_IMPORTED_MODULE_1___default().get(`${url}`, {
            headers: {
                Authorization: `Bearer ${accessToken}`
            }
        }).then((res)=>{
            if (!res.data.ok) throw new Error(res.data.message);
            return res.data.members;
        });
    };
    const { data , error  } = swr__WEBPACK_IMPORTED_MODULE_0___default()(url2, fetcher);
    return {
        members: data,
        loadMembersError: error
    };
}
function useGithubOrgActivities(url3 = "") {
    const fetcher = async (url)=>{
        const accessToken = await getAccessToken();
        return await axios__WEBPACK_IMPORTED_MODULE_1___default().get(`${url}`, {
            headers: {
                Authorization: `Bearer ${accessToken}`
            }
        }).then((res)=>res.data.activities
        );
    };
    const { data , error  } = swr__WEBPACK_IMPORTED_MODULE_0___default()(url3, fetcher, {
        refreshInterval: 500
    });
    return {
        activities: data,
        loadActivitiesError: error
    };
}
async function createNewTeam(url = "", team) {
    const accessToken = await getAccessToken();
    const result = await axios__WEBPACK_IMPORTED_MODULE_1___default().post(url, {
        team
    }, {
        headers: {
            Authorization: `Bearer ${accessToken}`
        }
    }).then((res)=>res.data
    );
    if (!(result === null || result === void 0 ? void 0 : result.ok)) throw new Error(result === null || result === void 0 ? void 0 : result.error);
    return result.team;
}
async function deleteTeam(url = "", team) {
    const accessToken = await getAccessToken();
    const result = await axios__WEBPACK_IMPORTED_MODULE_1___default()["delete"](url, {
        data: {
            teamSlug: team
        },
        headers: {
            Authorization: `Bearer ${accessToken}`
        }
    }).then((res)=>res.data
    );
    if (!(result === null || result === void 0 ? void 0 : result.ok)) throw new Error(result === null || result === void 0 ? void 0 : result.error);
    return result;
}
async function inviteMemberToTeam(url = "", teamSlug, memberAccount) {
    const accessToken = await getAccessToken();
    const result = await axios__WEBPACK_IMPORTED_MODULE_1___default().post(url, {
        teamSlug,
        member: memberAccount
    }, {
        headers: {
            Authorization: `Bearer ${accessToken}`
        }
    }).then((res)=>res.data
    ).catch((err)=>{
        throw new Error(err);
    });
    if (!(result === null || result === void 0 ? void 0 : result.ok)) throw new Error(result === null || result === void 0 ? void 0 : result.error);
    return result;
}
async function removeMemberFromTeam(url = "", teamSlug, memberAccount) {
    const accessToken = await getAccessToken();
    const result = await axios__WEBPACK_IMPORTED_MODULE_1___default()["delete"](url, {
        data: {
            teamSlug,
            member: memberAccount
        },
        headers: {
            Authorization: `Bearer ${accessToken}`
        }
    }).then((res)=>res.data
    ).catch((err)=>{
        throw new Error(err);
    });
    if (!(result === null || result === void 0 ? void 0 : result.ok)) throw new Error(result === null || result === void 0 ? void 0 : result.error);
}


/***/ })

};
;