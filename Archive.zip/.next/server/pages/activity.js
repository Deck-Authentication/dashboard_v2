"use strict";
(() => {
var exports = {};
exports.id = 839;
exports.ids = [839];
exports.modules = {

/***/ 3067:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Activity),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5313);
/* harmony import */ var _components_spinner__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3891);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);





function Activity({ BACKEND_URL  }) {
    const { admin , loadAdminError  } = (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .useAdminData */ .QY)(`${BACKEND_URL}/admin/get-all-data`);
    const { activities , loadActivitiesError  } = (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .useGithubOrgActivities */ .SL)(`${BACKEND_URL}/github/list-activities?perPage=100`);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
    if (loadAdminError) return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        children: "Unable to load your data. Contact us at peter@withdeck.com and we will resolve this issue as soon as possible"
    }));
    else if (!admin) return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "w-full h-full flex justify-center items-center",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_spinner__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {})
    }));
    const { github  } = admin;
    if (!(github === null || github === void 0 ? void 0 : github.apiKey) || !(github === null || github === void 0 ? void 0 : github.organization)) {
        router.push("/onboarding");
        return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "w-full h-full flex justify-center items-center",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_spinner__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {})
        }));
    }
    if (loadActivitiesError) return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        children: "Error loading activities"
    }));
    else if (!activities) return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "w-full h-full flex justify-center items-center",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_spinner__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {})
    }));
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "activities px-8",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "w-full border-b border-b-black my-8",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                    className: "text-4xl font-bold",
                    children: "Activity"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                children: activities.map((activity, loopId)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                        className: "log-msg border border-gray-300 p-2",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(LogMessage, {
                            activity: activity
                        })
                    }, loopId)
                )
            })
        ]
    }));
};
function LogMessage({ activity  }) {
    const unixTimestampToDate = (unixTimestamp)=>{
        const date = new Date(unixTimestamp);
        return date.toLocaleString("en-US", {
            timeZoneName: "short"
        });
    };
    const { action , actor , created_at , user , org , team  } = activity;
    let actionVerb = "", actionSubject = "to";
    switch(action){
        case "team.add_member":
        case "org.add_member":
            actionVerb = "added";
            break;
        case "team.remove_member":
        case "org.remove_member":
            actionVerb = "removed";
            actionSubject = "from";
            break;
        case "org.invite_member":
            actionVerb = "invited";
            break;
        default:
            actionVerb = "(undetected activity)";
            break;
    }
    const destination = ()=>{
        const content = team ? team : org;
        const href = team ? `https://github.com/orgs/${org}/teams/${team.split("/")[1]}` : `https://github.com/${org}`;
        return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
            href: href,
            className: "text-blue-600 font-semibold hover:underline",
            target: "_blank",
            rel: "noopener noreferrer",
            children: content
        }));
    };
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                href: `https://github.com/${actor}`,
                className: "text-blue-600 font-semibold hover:underline",
                target: "_blank",
                rel: "noopener noreferrer",
                children: actor
            }),
            " ",
            actionVerb,
            " ",
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                href: `https://github.com/${user}`,
                className: "text-blue-600 font-semibold hover:underline",
                target: "_blank",
                rel: "noopener noreferrer",
                children: user
            }),
            " ",
            actionSubject,
            " the ",
            destination(),
            " ",
            team ? "team" : "organization",
            "| Time: ",
            unixTimestampToDate(created_at)
        ]
    }));
}
async function getStaticProps() {
    const BACKEND_URL = process.env.BACKEND_URL;
    return {
        props: {
            BACKEND_URL
        }
    };
}


/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 549:
/***/ ((module) => {

module.exports = require("swr");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [962], () => (__webpack_exec__(3067)));
module.exports = __webpack_exports__;

})();