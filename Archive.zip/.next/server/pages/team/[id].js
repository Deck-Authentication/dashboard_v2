"use strict";
(() => {
var exports = {};
exports.id = 186;
exports.ids = [186];
exports.modules = {

/***/ 9066:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Team),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5313);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5675);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1187);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_toastify__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7821);
/* harmony import */ var swr__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(549);
/* harmony import */ var swr__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(swr__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7197);
/* harmony import */ var _fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6466);
/* harmony import */ var _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _components_spinner__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(3891);











function Team({ id , BACKEND_URL  }) {
    const teamSlug = id;
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const { repos , loadReposError  } = (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .useGithubTeamRepos */ .YH)(`${BACKEND_URL}/github/team/list-repos?teamSlug=${teamSlug}`);
    const { members , loadMembersError  } = (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .useGithubTeamMembers */ .XX)(`${BACKEND_URL}/github/team/list-members?teamSlug=${teamSlug}`);
    const { 0: tab , 1: setTab  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(router.query.tab || "repositories");
    if (loadReposError) return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        children: "Failed to load repos"
    }));
    else if (loadMembersError) return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        children: "Failed to load members"
    }));
    if (!repos || !members) return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "w-full h-full flex justify-center items-center",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_spinner__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {})
    }));
    const handleTabChange = (event, newTab)=>{
        event.preventDefault();
        setTab(newTab);
    };
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "team w-full h-full p-5",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                className: "text-4xl font-bold mb-10",
                children: teamSlug
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "tabs my-4",
                "data-theme": "corporate",
                children: [
                    "repositories",
                    "members"
                ].map((_tab, loopId)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                        className: `capitalize tab tab-bordered ${_tab === tab ? "font-bold border-orange-600" : ""}`,
                        onClick: (e)=>handleTabChange(e, _tab)
                        ,
                        children: _tab
                    }, `${_tab}-${loopId}`)
                )
            }),
            tab === "repositories" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TeamRepos, {
                repos: repos
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TeamMembers, {
                members: members,
                teamSlug: id,
                BACKEND_URL: BACKEND_URL
            })
        ]
    }));
};
function TeamRepos({ repos  }) {
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("table", {
        className: "w-full border-collapse",
        "data-theme": "light",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                className: "border-2 border-black p-2",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                            className: "text-left p-2",
                            children: "Name"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                            className: "text-left p-2",
                            children: "Role"
                        })
                    ]
                })
            }),
            repos.map((repo, loopId)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                    className: "w-full border-2 border-black p-2",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                        className: "w-full border border-black rounded-lg",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                className: "p-2",
                                children: repo.name
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                className: "p-2",
                                children: repo.role_name
                            })
                        ]
                    })
                }, loopId)
            )
        ]
    }));
}
function TeamMembers({ members , teamSlug , BACKEND_URL  }) {
    const { 0: isCreating , 1: setIsCreating  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    const { mutate  } = (0,swr__WEBPACK_IMPORTED_MODULE_7__.useSWRConfig)();
    const handleMemberAdd = async (memberAccount)=>{
        // avoid inviting empty-string members
        if (!memberAccount) return;
        setIsCreating(true);
        const response = await (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .inviteMemberToTeam */ .Dd)(`${BACKEND_URL}/github/team/invite-member`, teamSlug, memberAccount);
        if (response.ok) {
            // reload the cache after adding a new member
            mutate(`${BACKEND_URL}/github/team/list-members?teamSlug=${teamSlug}`);
            react_toastify__WEBPACK_IMPORTED_MODULE_5__.toast.success("Member added", _constants__WEBPACK_IMPORTED_MODULE_6__/* .toastOption */ .X);
        } else react_toastify__WEBPACK_IMPORTED_MODULE_5__.toast.error(`Error in adding ${memberAccount}`, _constants__WEBPACK_IMPORTED_MODULE_6__/* .toastOption */ .X);
        setIsCreating(false);
    };
    const handleMemberRemove = async (memberAccount)=>{
        // avoid removing empty-string members
        if (!memberAccount) return;
        try {
            await (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .removeMemberFromTeam */ .F0)(`${BACKEND_URL}/github/team/remove-member`, teamSlug, memberAccount);
            // reload the cache after adding a new member
            mutate(`${BACKEND_URL}/github/team/list-members?teamSlug=${teamSlug}`);
            react_toastify__WEBPACK_IMPORTED_MODULE_5__.toast.success(`${memberAccount} is successfully removed from your team`, _constants__WEBPACK_IMPORTED_MODULE_6__/* .toastOption */ .X);
        } catch (error) {
            react_toastify__WEBPACK_IMPORTED_MODULE_5__.toast.error(`Error in removing ${memberAccount}`, _constants__WEBPACK_IMPORTED_MODULE_6__/* .toastOption */ .X);
        }
    };
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "flex flex-col gap-4",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(AddMemberBtn, {
                isCreating: isCreating,
                handleMemberAdd: handleMemberAdd
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                children: members.map((member, key)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "border border-black flex flex-row justify-between items-center py-2 px-4",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                className: "flex flex-row items-center gap-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_image__WEBPACK_IMPORTED_MODULE_4__["default"], {
                                        className: "mask mask-circle ring ring-primary ring-blue-500 ring-offset-2",
                                        src: member.avatar_url,
                                        alt: `User ${member.login}`,
                                        width: 50,
                                        height: 50,
                                        priority: true
                                    }),
                                    member.login
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_8__.FontAwesomeIcon, {
                                icon: _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__.faTrashAlt,
                                width: "20",
                                height: "20",
                                className: "cursor-pointer hover:text-red-400",
                                onClick: (_)=>handleMemberRemove(member.login)
                            })
                        ]
                    }, key)
                )
            })
        ]
    }));
}
function AddMemberBtn({ isCreating , handleMemberAdd  }) {
    const { 0: memberAccount , 1: setMemberAccount  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)("");
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "add-member-btn w-full flex justify-end",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                htmlFor: "add-template-modal",
                className: "modal-button pill-btn btn-primary cursor-pointer normal-case p-1 hover:opacity-90",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                        xmlns: "http://www.w3.org/2000/svg",
                        className: "h-5 w-5 mr-1",
                        viewBox: "0 0 20 20",
                        fill: "currentColor",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                            fillRule: "evenodd",
                            d: "M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z",
                            clipRule: "evenodd"
                        })
                    }),
                    "Add Member"
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                type: "checkbox",
                id: "add-template-modal",
                className: "modal-toggle"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "modal",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "modal-box bg-white p-10",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                            type: "text",
                            placeholder: "Member account",
                            className: "text-xl w-full rounded-2xl p-2 border border-blue-300",
                            value: memberAccount,
                            onChange: (event)=>setMemberAccount(event.target.value)
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "modal-action",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                    htmlFor: "add-template-modal",
                                    className: `btn btn-primary ${isCreating ? "loading" : ""}`,
                                    onClick: async (event)=>{
                                        event.preventDefault();
                                        handleMemberAdd(memberAccount);
                                    },
                                    children: "Add"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                    htmlFor: "add-template-modal",
                                    className: "btn",
                                    children: "Cancel"
                                })
                            ]
                        })
                    ]
                })
            })
        ]
    }));
}
async function getServerSideProps({ params  }) {
    const BACKEND_URL = process.env.BACKEND_URL || "http://localhost:8080";
    const id = params.id;
    return {
        props: {
            id,
            BACKEND_URL
        }
    };
}


/***/ }),

/***/ 6466:
/***/ ((module) => {

module.exports = require("@fortawesome/free-solid-svg-icons");

/***/ }),

/***/ 7197:
/***/ ((module) => {

module.exports = require("@fortawesome/react-fontawesome");

/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 8028:
/***/ ((module) => {

module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3018:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 1187:
/***/ ((module) => {

module.exports = require("react-toastify");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 549:
/***/ ((module) => {

module.exports = require("swr");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [190,675,962,821], () => (__webpack_exec__(9066)));
module.exports = __webpack_exports__;

})();