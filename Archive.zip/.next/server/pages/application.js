"use strict";
(() => {
var exports = {};
exports.id = 961;
exports.ids = [961];
exports.modules = {

/***/ 9623:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Application),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "@fortawesome/react-fontawesome"
var react_fontawesome_ = __webpack_require__(7197);
// EXTERNAL MODULE: external "@fortawesome/free-solid-svg-icons"
var free_solid_svg_icons_ = __webpack_require__(6466);
;// CONCATENATED MODULE: ./assets/Github_Mark.png
/* harmony default export */ const Github_Mark = ({"src":"/_next/static/media/Github_Mark.df059a84.png","height":120,"width":120,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAKlBMVEUWFBUXFBUWFBUWFBUXFBUXFBUWFRYWFBUXFBUXFRYXFRUXFRYXFRYWFBXDAE/HAAAADXRSTlMC8aUWJN69PdCPWn14VMGJqAAAAAlwSFlzAAALEwAACxMBAJqcGAAAADZJREFUCJktxskBgDAMBLFZ3wTcf7t8opfALWUBPpI0gSURTLEPwLs331J54GjoMvfdhjanmh8kHgEeHdUdTQAAAABJRU5ErkJggg=="});
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: ./utils/index.js
var utils = __webpack_require__(5313);
;// CONCATENATED MODULE: external "formik"
const external_formik_namespaceObject = require("formik");
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react-toastify"
var external_react_toastify_ = __webpack_require__(1187);
// EXTERNAL MODULE: ./constants/index.js
var constants = __webpack_require__(7821);
// EXTERNAL MODULE: ./components/spinner/index.js
var spinner = __webpack_require__(3891);
;// CONCATENATED MODULE: ./pages/application.js

// FontAwesome import










function Application({ BACKEND_URL  }) {
    const { admin , loadAdminError  } = (0,utils/* useAdminData */.QY)(`${BACKEND_URL}/admin/get-all-data`);
    if (loadAdminError) return(/*#__PURE__*/ jsx_runtime_.jsx("div", {
        children: "failed to load"
    }));
    if (!admin) return(/*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "w-full h-full flex justify-center items-center",
        children: /*#__PURE__*/ jsx_runtime_.jsx(spinner/* default */.Z, {})
    }));
    const { github  } = admin;
    const handleSave = async (newApiKey, newOrganization)=>{
        // Only fetch new data as members and teams from github if the organization field has changed
        const shouldGithubDataUpdate = newOrganization !== github.organization;
        await Promise.all([
            (0,utils/* saveGithubCredentials */.cC)(`${BACKEND_URL}/github/save-credentials`, newApiKey, newOrganization)
        ]).then(async ()=>{
            if (shouldGithubDataUpdate) await (0,utils/* importNewData */.Dj)(`${BACKEND_URL}/github/import-all`).catch((err)=>{
                throw new Error(err);
            });
            external_react_toastify_.toast.success("Github credentials saved successfully", constants/* toastOption */.X);
        }).catch((err)=>{
            console.error(err);
            external_react_toastify_.toast.error("Failed to save Github credentials. Contact us at peter@withdeck.com and we'll resolve this issue as soon as possible", constants/* toastOption */.X);
        });
    };
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        id: "application",
        className: "w-full h-full flex justify-center p-10",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                className: "w-10/12 w-md-full flex flex-col gap-y-4",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                    className: "w-full border rounded-sm border-gray-300 p-3 flex flex-row justify-between items-center",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex flex-row items-center gap-1",
                            title: "github",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                                    src: Github_Mark,
                                    alt: "Github logo",
                                    height: "25",
                                    width: "25",
                                    priority: true
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Github"
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("label", {
                            htmlFor: "github-modal",
                            className: "rounded-lg py-1 px-2 border border-transparent hover:shadow-md hover:border-gray-300 cursor-pointer",
                            title: "Setting",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(react_fontawesome_.FontAwesomeIcon, {
                                icon: free_solid_svg_icons_.faCog,
                                width: "20",
                                height: "20"
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(AppSettings, {
                header: "Github App Setting",
                label: "github-modal",
                github: github,
                handleSave: handleSave
            })
        ]
    }));
};
function AppSettings({ header , label , github , handleSave  }) {
    const { apiKey , organization  } = github;
    const modalOpenCheckbox = (0,external_react_.useRef)(null);
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        "data-theme": "corporate",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                type: "checkbox",
                id: label,
                className: "modal-toggle",
                ref: modalOpenCheckbox
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("label", {
                htmlFor: label,
                className: "modal cursor-pointer",
                children: /*#__PURE__*/ jsx_runtime_.jsx(external_formik_namespaceObject.Formik, {
                    initialValues: {
                        tempApiKey: apiKey,
                        tempOrg: organization
                    },
                    validate: (values)=>{
                        const errors = {};
                        if (!values.tempApiKey) errors.tempApiKey = "API Key is required";
                        if (!values.tempOrg) errors.tempOrg = "Organization is required";
                        return errors;
                    },
                    onSubmit: async (values, { setSubmitting  })=>{
                        // update the new Github API Key & Organization to the database
                        // then later refetch the list of teams & members from Github to Deck's database
                        await handleSave(values.tempApiKey, values.tempOrg);
                        setSubmitting(false);
                        modalOpenCheckbox.current.checked = false;
                    },
                    children: ({ isSubmitting  })=>/*#__PURE__*/ jsx_runtime_.jsx(external_formik_namespaceObject.Form, {
                            className: "bg-white overflow-y-scroll rounded-lg",
                            style: {
                                minWidth: "700px",
                                maxHeight: "80%"
                            },
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                className: "modal-box relative p-0",
                                htmlFor: "",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "modal-header text-xl font-bold p-4 w-full flex flex-row justify-between",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                children: header
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                htmlFor: label,
                                                className: "cursor-pointer",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(react_fontawesome_.FontAwesomeIcon, {
                                                    icon: free_solid_svg_icons_.faTimes,
                                                    width: "25",
                                                    height: "25"
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "modal-body w-full p-4 border-y flex flex-col gap-y-2 ",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "w-full bg-gray-200 p-4 rounded-sm flex flex-col gap-y-2",
                                                "data-theme": "corporate",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                        className: "font-semibold",
                                                        children: "Instructions"
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                        children: [
                                                            "To get your personal access token, click onto the",
                                                            " ",
                                                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                className: "text-green-400 font-semibold",
                                                                children: "Get your Credentials"
                                                            }),
                                                            " button below and create a new token.",
                                                            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                                            "Your token must include the ",
                                                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                className: "text-green-400 font-semibold",
                                                                children: "admin:org"
                                                            }),
                                                            " scope and should be expired in one year."
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                        className: "btn w-full hover:opacity-80",
                                                        href: "https://github.com/settings/tokens/new",
                                                        target: "_blank",
                                                        rel: "noreferrer",
                                                        children: [
                                                            "Get Your Credentials",
                                                            /*#__PURE__*/ jsx_runtime_.jsx(react_fontawesome_.FontAwesomeIcon, {
                                                                icon: free_solid_svg_icons_.faArrowRight,
                                                                width: "20",
                                                                height: "20",
                                                                className: "ml-1"
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        className: "btn btn-info w-full hover:opacity-80",
                                                        children: "Watch a guide video"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "flex flex-col gap-1 text-lg",
                                                children: [
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                                        htmlFor: "github-api-key",
                                                        children: [
                                                            "API key",
                                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                className: "text-red-600",
                                                                children: "*"
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: "flex flex-col gap-2",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx(external_formik_namespaceObject.Field, {
                                                                type: "text",
                                                                name: "tempApiKey",
                                                                className: "rounded-sm p-1 grow border-2 border-gray-400"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx(external_formik_namespaceObject.ErrorMessage, {
                                                                name: "tempApiKey",
                                                                component: "p",
                                                                className: "text-red-500"
                                                            })
                                                        ]
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "flex flex-col gap-1 text-lg",
                                                children: [
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                                        htmlFor: "github-org",
                                                        children: [
                                                            "Organization",
                                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                className: "text-red-600",
                                                                children: "*"
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: "flex flex-col gap-2",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx(external_formik_namespaceObject.Field, {
                                                                type: "text",
                                                                name: "tempOrg",
                                                                className: "rounded-sm p-1 grow border-2 border-gray-400"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx(external_formik_namespaceObject.ErrorMessage, {
                                                                name: "tempOrg",
                                                                component: "p",
                                                                className: "text-red-500"
                                                            })
                                                        ]
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "alert alert-warning shadow-lg",
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                                            xmlns: "http://www.w3.org/2000/svg",
                                                            className: "stroke-current flex-shrink-0 h-6 w-6",
                                                            fill: "none",
                                                            viewBox: "0 0 24 24",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                                strokeLinecap: "round",
                                                                strokeLinejoin: "round",
                                                                strokeWidth: "2",
                                                                d: "M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                            children: [
                                                                "Warning: Adding a new ",
                                                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                    children: "Organization"
                                                                }),
                                                                " will reload your Github teams under the Team tab. Make sure your configurations are accurate."
                                                            ]
                                                        })
                                                    ]
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "w-full p-4 flex flex-row justify-end",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                            className: `btn btn-primary text-white ${isSubmitting ? "loading" : ""}`,
                                            type: "submit",
                                            disabled: isSubmitting,
                                            children: "Save"
                                        })
                                    })
                                ]
                            })
                        })
                })
            })
        ]
    }));
}
async function getStaticProps() {
    const BACKEND_URL = process.env.BACKEND_URL;
    return {
        props: {
            BACKEND_URL
        }
    };
}


/***/ }),

/***/ 6466:
/***/ ((module) => {

module.exports = require("@fortawesome/free-solid-svg-icons");

/***/ }),

/***/ 7197:
/***/ ((module) => {

module.exports = require("@fortawesome/react-fontawesome");

/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 8028:
/***/ ((module) => {

module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3018:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 1187:
/***/ ((module) => {

module.exports = require("react-toastify");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 549:
/***/ ((module) => {

module.exports = require("swr");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [190,675,962,821], () => (__webpack_exec__(9623)));
module.exports = __webpack_exports__;

})();