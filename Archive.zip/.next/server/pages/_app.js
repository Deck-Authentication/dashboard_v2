(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 4457:
/***/ ((module) => {

// Exports
module.exports = {
	"spinner": "styles_spinner__OeeP6"
};


/***/ }),

/***/ 3891:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Spinner)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_module_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4457);
/* harmony import */ var _styles_module_scss__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styles_module_scss__WEBPACK_IMPORTED_MODULE_1__);


function Spinner() {
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
        className: (_styles_module_scss__WEBPACK_IMPORTED_MODULE_1___default().spinner),
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("circle", {
            cx: "30",
            cy: "30",
            r: "28"
        })
    }));
};


/***/ }),

/***/ 6575:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "axios"
var external_axios_ = __webpack_require__(2167);
var external_axios_default = /*#__PURE__*/__webpack_require__.n(external_axios_);
;// CONCATENATED MODULE: ./context/index.js



const AppContext = /*#__PURE__*/ (0,external_react_.createContext)();
function AppWrapper(props) {
    // set context as a state so children components will rerender when context changes
    const { 0: context , 1: setContext  } = (0,external_react_.useState)({});
    (0,external_react_.useEffect)(()=>{
        const getAccessToken = async ()=>{
            const { accessToken  } = await external_axios_default().get("/api/get-access-token").then((res)=>res.data
            );
            setContext({
                ...context,
                accessToken
            });
        };
        getAccessToken();
    // eslint-disable-next-line react-hooks/exhaustive-deps
    });
    return(/*#__PURE__*/ jsx_runtime_.jsx(AppContext.Provider, {
        value: [
            context,
            setContext
        ],
        children: props.children
    }));
};
function useAppContext() {
    const context = (0,external_react_.useContext)(AppContext);
    if (context === undefined) throw new Error("useAppContext must be used within the Context Provider- AppWrapper");
    return (0,external_react_.useContext)(AppContext);
}

// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
;// CONCATENATED MODULE: ./components/menu.js


function Menu() {
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("aside", {
        className: "min-h-full bg-zinc-800 text-white py-5 px-3",
        style: {
            minWidth: "260px"
        },
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                href: "/team",
                passHref: true,
                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        className: "text-indigo-400 text-4xl px-3 mb-3 font-bold",
                        children: "Deck"
                    })
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                className: "p-4 overflow-y-auto w-full text-base-content",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                            href: "/team",
                            passHref: true,
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                className: "flex flex-row my-px p-3 rounded-lg hover:bg-slate-700",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                        xmlns: "http://www.w3.org/2000/svg",
                                        className: "h-6 w-6 p-0.5 mr-0.5 rounded",
                                        fill: "currentColor",
                                        viewBox: "0 0 24 24",
                                        stroke: "currentColor",
                                        style: {
                                            background: "linear-gradient(to right, #009fff, #ec2f4b)"
                                        },
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round",
                                            strokeWidth: 2,
                                            d: "M4 5a1 1 0 011-1h14a1 1 0 011 1v2a1 1 0 01-1 1H5a1 1 0 01-1-1V5zM4 13a1 1 0 011-1h6a1 1 0 011 1v6a1 1 0 01-1 1H5a1 1 0 01-1-1v-6zM16 13a1 1 0 011-1h2a1 1 0 011 1v6a1 1 0 01-1 1h-2a1 1 0 01-1-1v-6z"
                                        })
                                    }),
                                    "Team"
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                            href: "/user",
                            passHref: true,
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                className: "flex flex-row my-px p-3 rounded-lg hover:bg-slate-700",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                        xmlns: "http://www.w3.org/2000/svg",
                                        className: "h-6 w-6 p-0.5 mr-0.5 rounded",
                                        viewBox: "0 0 20 20",
                                        fill: "currentColor",
                                        stroke: "currentColor",
                                        style: {
                                            background: "linear-gradient(to right, #ff5f6d, #ffc371)"
                                        },
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            fillRule: "evenodd",
                                            d: "M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z",
                                            clipRule: "evenodd"
                                        })
                                    }),
                                    "User"
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                            href: "/activity",
                            passHref: true,
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                className: "flex flex-row my-px p-3 rounded-lg hover:bg-slate-700",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                        xmlns: "http://www.w3.org/2000/svg",
                                        className: "h-6 w-6 p-0.5 mr-0.5 rounded",
                                        fill: "linear-gradient(to right, #b2fefa, #0ed2f7)",
                                        viewBox: "0 0 20 20",
                                        stroke: "currentColor",
                                        style: {
                                            background: "linear-gradient(to right, #74ebd5, #acb6e5)"
                                        },
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round",
                                            d: "M7 12l3-3 3 3 4-4M8 21l4-4 4 4M3 4h18M4 4h16v12a1 1 0 01-1 1H5a1 1 0 01-1-1V4z"
                                        })
                                    }),
                                    "Activity"
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                            href: "/application",
                            passHref: true,
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                className: "flex flex-row my-px p-3 rounded-lg hover:bg-slate-700",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                        xmlns: "http://www.w3.org/2000/svg",
                                        className: "h-6 w-6 p-0.5 mr-0.5 rounded",
                                        viewBox: "0 0 20 20",
                                        fill: "currentColor",
                                        stroke: "currentColor",
                                        style: {
                                            background: "linear-gradient(to right, #76b852, #8dc26f)"
                                        },
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            fillRule: "evenodd",
                                            d: "M2 5a2 2 0 012-2h12a2 2 0 012 2v10a2 2 0 01-2 2H4a2 2 0 01-2-2V5zm3.293 1.293a1 1 0 011.414 0l3 3a1 1 0 010 1.414l-3 3a1 1 0 01-1.414-1.414L7.586 10 5.293 7.707a1 1 0 010-1.414zM11 12a1 1 0 100 2h3a1 1 0 100-2h-3z",
                                            clipRule: "evenodd"
                                        })
                                    }),
                                    "Application"
                                ]
                            })
                        })
                    })
                ]
            })
        ]
    }));
};

;// CONCATENATED MODULE: external "@headlessui/react"
const react_namespaceObject = require("@headlessui/react");
;// CONCATENATED MODULE: external "@auth0/nextjs-auth0"
const nextjs_auth0_namespaceObject = require("@auth0/nextjs-auth0");
// EXTERNAL MODULE: ./components/spinner/index.js
var spinner = __webpack_require__(3891);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
;// CONCATENATED MODULE: ./components/header.js






function Header() {
    const router = (0,router_.useRouter)();
    const { user , error , isLoading  } = (0,nextjs_auth0_namespaceObject.useUser)();
    const [_, setContext] = useAppContext();
    const handleLogout = (event)=>{
        event.preventDefault();
        // clean up context before logging out
        setContext({});
        router.push("/api/auth/logout");
    };
    if (isLoading) return(/*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "w-full h-full flex justify-center items-center",
        children: /*#__PURE__*/ jsx_runtime_.jsx(spinner/* default */.Z, {})
    }));
    if (error) return(/*#__PURE__*/ jsx_runtime_.jsx("div", {
        children: error.message
    }));
    return user ? /*#__PURE__*/ jsx_runtime_.jsx("header", {
        className: "flex-none px-5 py-4 bg-white flex justify-end",
        style: {
            boxShadow: "0 8px 6px -6px #ccc",
            height: "60px"
        },
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_namespaceObject.Popover, {
            className: "relative",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_namespaceObject.Popover.Button, {
                    tabIndex: "0",
                    className: "m-1 flex flex-row pl-2 border-l-slate-400 items-end cursor-pointer hover:opacity-70",
                    style: {
                        borderLeftWidth: "0.5px"
                    },
                    children: [
                        user.name || user.email,
                        /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                            xmlns: "http://www.w3.org/2000/svg",
                            className: "h-5 w-5",
                            viewBox: "0 0 20 20",
                            fill: "currentColor",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                fillRule: "evenodd",
                                d: "M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z",
                                clipRule: "evenodd"
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(react_namespaceObject.Popover.Panel, {
                    className: "absolute z-10 right-0 mt-2 bg-white border border-gray-300 p-1 w-52 rounded-xl",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                        tabIndex: "0",
                        className: "p-2 rounded-box w-full",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            href: "#",
                            onClick: (event)=>handleLogout(event)
                            ,
                            children: /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                className: "hover:bg-zinc-100 rounded-box p-2 rounded-xl",
                                children: "Log out"
                            })
                        })
                    })
                })
            ]
        })
    }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h1", {
        children: [
            "No user found. Contact us at",
            " ",
            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                href: "mailto:peter@withdeck.com",
                className: "underline text-blue-800",
                children: "peter@withdeck.com"
            }),
            " ",
            "and we will resolve this issue as soon as possible."
        ]
    });
};

// EXTERNAL MODULE: ./node_modules/react-toastify/dist/ReactToastify.css
var ReactToastify = __webpack_require__(8819);
// EXTERNAL MODULE: external "react-toastify"
var external_react_toastify_ = __webpack_require__(1187);
;// CONCATENATED MODULE: ./components/layout.js






function Layout(props) {
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-row min-h-screen min-w-screen text-black relative",
        style: {
            backgroundColor: "rgb(241, 245, 249)"
        },
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Menu, {}),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "grow h-screen flex flex-col",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(Header, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx("section", {
                        className: "w-full h-full overflow-y-scroll",
                        children: props.children
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(external_react_toastify_.ToastContainer, {})
                ]
            })
        ]
    }));
}
/* harmony default export */ const layout = ((0,nextjs_auth0_namespaceObject.withPageAuthRequired)(Layout));

;// CONCATENATED MODULE: external "next/head"
const head_namespaceObject = require("next/head");
var head_default = /*#__PURE__*/__webpack_require__.n(head_namespaceObject);
;// CONCATENATED MODULE: ./pages/_app.js






function MyApp({ Component , pageProps  }) {
    return(/*#__PURE__*/ jsx_runtime_.jsx(nextjs_auth0_namespaceObject.UserProvider, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AppWrapper, {
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("title", {
                            children: "Deck"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                            name: "title",
                            content: "Deck Admin Dashboard"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                            name: "description",
                            content: "Deck Admin Dashboard for https://withdeck.com- an application to help you invite teammates into multiple cloud applications in one click"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("link", {
                            rel: "icon",
                            href: "/deck.ico"
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(layout, {
                    children: /*#__PURE__*/ jsx_runtime_.jsx(Component, {
                        ...pageProps
                    })
                })
            ]
        })
    }));
}
/* harmony default export */ const _app = (MyApp);


/***/ }),

/***/ 8819:
/***/ (() => {



/***/ }),

/***/ 2167:
/***/ ((module) => {

"use strict";
module.exports = require("axios");

/***/ }),

/***/ 562:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 1187:
/***/ ((module) => {

"use strict";
module.exports = require("react-toastify");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [190,676,664], () => (__webpack_exec__(6575)));
module.exports = __webpack_exports__;

})();