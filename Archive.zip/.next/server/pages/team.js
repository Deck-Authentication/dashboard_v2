"use strict";
(() => {
var exports = {};
exports.id = 38;
exports.ids = [38];
exports.modules = {

/***/ 305:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Teams),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./utils/index.js
var utils = __webpack_require__(5313);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
;// CONCATENATED MODULE: external "@heroicons/react/solid"
const solid_namespaceObject = require("@heroicons/react/solid");
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./components/team/index.js





function TeamCard({ team , cardKey , BACKEND_URL , href , handleDeleteTeam  }) {
    const { name , slug  } = team;
    const borderTopColors = [
        "border-t-blue-300",
        "border-t-red-300",
        "border-t-green-300",
        "border-t-purple-300",
        "border-t-orange-300",
        "border-t-yellow-300", 
    ];
    const cardBorderTopColor = borderTopColors[cardKey % 6];
    const TeamCardStyles = `defined-card relative w-1/5 min-w-max h-36 mt-2 mr-2 bg-white cursor-pointer hover:shadow-lg border-gray-100 border-t-8 ${cardBorderTopColor}`;
    const { repos , loadReposError  } = (0,utils/* useGithubTeamRepos */.YH)(`${BACKEND_URL}/github/team/list-repos?teamSlug=${slug}`);
    const { members , loadMembersError  } = (0,utils/* useGithubTeamMembers */.XX)(`${BACKEND_URL}/github/team/list-members?teamSlug=${slug}`);
    if (loadReposError) return(/*#__PURE__*/ jsx_runtime_.jsx("div", {
        children: "Failed to load repos"
    }));
    else if (loadMembersError) return(/*#__PURE__*/ jsx_runtime_.jsx("div", {
        children: "Failed to load team members"
    }));
    if (!members || !repos) return(/*#__PURE__*/ jsx_runtime_.jsx("div", {
        children: "Loading..."
    }));
    return(/*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
        href: href,
        passHref: true,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
            className: TeamCardStyles,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(solid_namespaceObject.XCircleIcon, {
                    className: "absolute z-10 h-6 w-6 top-0 right-0 hover:text-red-600",
                    onClick: (event)=>{
                        event.preventDefault();
                        handleDeleteTeam(team);
                    }
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "card-body",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "card-title w-full flex justify-between",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                children: name
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            children: [
                                "Number of repositories: ",
                                repos ? repos.length : 0
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            children: [
                                "Number of members: ",
                                members ? members.length : 0
                            ]
                        })
                    ]
                })
            ]
        })
    }, cardKey));
}
function CreateTeamBtn({ isCreating , handleCreateTeam  }) {
    const { 0: teamName , 1: setTeamName  } = (0,external_react_.useState)("");
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "create-team-btn w-full flex",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                htmlFor: "add-template-modal",
                className: "modal-button btn btn-primary btn-sm cursor-pointer normal-case p-1 hover:opacity-90",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                        xmlns: "http://www.w3.org/2000/svg",
                        className: "h-5 w-5 mr-1",
                        viewBox: "0 0 20 20",
                        fill: "currentColor",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                            fillRule: "evenodd",
                            d: "M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z",
                            clipRule: "evenodd"
                        })
                    }),
                    "Create Team"
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                type: "checkbox",
                id: "add-template-modal",
                className: "modal-toggle"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "modal",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "modal-box bg-white p-10",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                            type: "text",
                            placeholder: "Team Name",
                            className: "text-xl w-full rounded-2xl p-2 border border-blue-300",
                            value: teamName,
                            onChange: (event)=>setTeamName(event.target.value)
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "modal-action",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                    htmlFor: "add-template-modal",
                                    className: `btn btn-primary ${isCreating ? "loading" : ""}`,
                                    onClick: async (event)=>{
                                        event.preventDefault();
                                        handleCreateTeam(teamName);
                                    },
                                    children: "Create"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                    htmlFor: "add-template-modal",
                                    className: "btn",
                                    children: "Cancel"
                                })
                            ]
                        })
                    ]
                })
            })
        ]
    }));
}

// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
;// CONCATENATED MODULE: external "lodash"
const external_lodash_namespaceObject = require("lodash");
var external_lodash_default = /*#__PURE__*/__webpack_require__.n(external_lodash_namespaceObject);
// EXTERNAL MODULE: external "react-toastify"
var external_react_toastify_ = __webpack_require__(1187);
// EXTERNAL MODULE: ./constants/index.js
var constants = __webpack_require__(7821);
// EXTERNAL MODULE: external "swr"
var external_swr_ = __webpack_require__(549);
// EXTERNAL MODULE: ./components/spinner/index.js
var spinner = __webpack_require__(3891);
;// CONCATENATED MODULE: ./pages/team/index.js










function Teams({ BACKEND_URL  }) {
    const { teams , teamsLoadError  } = (0,utils/* useGithubTeams */.EW)(`${BACKEND_URL}/github/team/list-all`);
    const { admin , loadAdminError  } = (0,utils/* useAdminData */.QY)(`${BACKEND_URL}/admin/get-all-data`);
    const { 0: isCreatingTeam , 1: setIsCreatingTeam  } = (0,external_react_.useState)(false);
    const { 0: isDeletingTeam , 1: setIsDeletingTeam  } = (0,external_react_.useState)(false);
    const { mutate  } = (0,external_swr_.useSWRConfig)();
    const router = (0,router_.useRouter)();
    const modalDeleteCheckbox = (0,external_react_.useRef)(null);
    const handleCreateTeam = async (newTeamName)=>{
        // disable the create team button while creating team
        setIsCreatingTeam(true);
        const newTeam = await (0,utils/* createNewTeam */.DY)(`${BACKEND_URL}/github/team/create`, newTeamName);
        setIsCreatingTeam(false);
        // redirect users to the new team page
        router.push(`${router.asPath}/${newTeam.slug}`);
    };
    const handleDeleteTeam = async (team)=>{
        setIsDeletingTeam(true);
        await (0,utils/* deleteTeam */.fC)(`${BACKEND_URL}/github/team/delete`, team.slug);
        // refetch the updated list of teams
        mutate(`${BACKEND_URL}/github/team/list-all`);
        setIsDeletingTeam(false);
        external_react_toastify_.toast.success(`Team ${team.name} deleted successfully`, constants/* toastOption */.X);
    };
    if (loadAdminError) return(/*#__PURE__*/ jsx_runtime_.jsx("div", {
        children: "Unable to load your data. Contact us at peter@withdeck.com and we will resolve this issue as soon as possible"
    }));
    else if (!admin) return(/*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "w-full h-full flex justify-center items-center",
        children: /*#__PURE__*/ jsx_runtime_.jsx(spinner/* default */.Z, {})
    }));
    const { github  } = admin;
    if (!(github === null || github === void 0 ? void 0 : github.apiKey) || !(github === null || github === void 0 ? void 0 : github.organization)) {
        router.push("/onboarding");
        return(/*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "w-full h-full flex justify-center items-center",
            children: /*#__PURE__*/ jsx_runtime_.jsx(spinner/* default */.Z, {})
        }));
    }
    if (teamsLoadError) {
        return(/*#__PURE__*/ jsx_runtime_.jsx("div", {
            children: "Unable to load teams. Contact us at peter@withdeck.com and we will resolve this issue as soon as possible"
        }));
    } else if (!teams) return(/*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "w-full h-full flex justify-center items-center",
        children: /*#__PURE__*/ jsx_runtime_.jsx(spinner/* default */.Z, {})
    }));
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "teams w-full h-full flex flex-col items-center p-5",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(CreateTeamBtn, {
                isCreating: isCreatingTeam,
                handleCreateTeam: handleCreateTeam
            }),
            external_lodash_default().isArray(teams) && teams.length > 0 ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "mt-5 flex w-full justify-start items-start flex-wrap gap-8",
                children: [
                    teams.map((team, loopId)=>/*#__PURE__*/ jsx_runtime_.jsx(TeamCard, {
                            cardKey: loopId,
                            team: team,
                            BACKEND_URL: BACKEND_URL,
                            href: `${router.asPath}/${team.slug}`,
                            handleDeleteTeam: handleDeleteTeam
                        }, `${team.id}-${loopId}`)
                    ),
                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                        type: "checkbox",
                        id: "delete-card-checkbox",
                        className: "modal-toggle",
                        ref: modalDeleteCheckbox
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "modal",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "modal-box bg-white p-10",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                    type: "text",
                                    placeholder: "Team Name",
                                    className: "text-xl w-full rounded-2xl p-2 border border-blue-300"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "modal-action",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                            htmlFor: "delete-card-checkbox",
                                            className: `btn btn-primary`,
                                            onClick: async (event)=>{
                                                event.preventDefault();
                                            },
                                            children: "Create"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                            htmlFor: "delete-card-checkbox",
                                            className: "btn",
                                            children: "Cancel"
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                ]
            }) : /*#__PURE__*/ jsx_runtime_.jsx("div", {
                children: "No team found"
            })
        ]
    }));
};
async function getStaticProps() {
    const BACKEND_URL = process.env.BACKEND_URL;
    return {
        props: {
            BACKEND_URL
        }
    };
}


/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 1187:
/***/ ((module) => {

module.exports = require("react-toastify");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 549:
/***/ ((module) => {

module.exports = require("swr");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [190,676,664,962,821], () => (__webpack_exec__(305)));
module.exports = __webpack_exports__;

})();