"use strict";
(() => {
var exports = {};
exports.id = 936;
exports.ids = [936];
exports.modules = {

/***/ 93:
/***/ ((module) => {

module.exports = require("@auth0/nextjs-auth0");

/***/ }),

/***/ 449:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _auth0_)
});

// EXTERNAL MODULE: external "@auth0/nextjs-auth0"
var nextjs_auth0_ = __webpack_require__(93);
;// CONCATENATED MODULE: external "dotenv"
const external_dotenv_namespaceObject = require("dotenv");
;// CONCATENATED MODULE: ./pages/api/auth/[...auth0].js


(0,external_dotenv_namespaceObject.config)();
// This is not the backend endpoint but the identifier name staying at https://manage.auth0.com/dashboard/us/dev-fh2bo4e4/apis/6226d19340ecc8004045f5c9/settings
const audience = "http://localhost:8080";
const handlers = (0,nextjs_auth0_.handleAuth)({
    async login (req, res) {
        try {
            await (0,nextjs_auth0_.handleLogin)(req, res, {
                authorizationParams: {
                    audience: audience,
                    // Add the `offline_access` scope to also get a Refresh Token
                    scope: "openid profile email offline_access read:current_user",
                    grant_type: "client_credentials"
                }
            });
        } catch (error) {
            res.status(error.status || 400).end(error.message);
        }
    }
});
/* harmony default export */ const _auth0_ = (handlers);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(449));
module.exports = __webpack_exports__;

})();